var __bridge = null
function __setupWebViewJavascriptBridge (callback) {
  if (window.WebViewJavascriptBridge) {
    return callback(window.WebViewJavascriptBridge)
  }
  if (window.WVJBCallbacks) {
    return window.WVJBCallbacks.push(callback)
  }
  window.WVJBCallbacks = [callback]
  var WVJBIframe = document.createElement('iframe')
  WVJBIframe.style.display = 'none'
  WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__'
  document.documentElement.appendChild(WVJBIframe)
  setTimeout(function () {
    document.documentElement.removeChild(WVJBIframe)
  }, 0)
}
__setupWebViewJavascriptBridge((b) => {
  __bridge = b
})
window.___WebToApp = function (name, params, cb) {
  __bridge.callHandler(name, params, function (responseData) {
    cb(responseData)
  })
}
window.__AppToWeb = function (name, cb) {
  __bridge.registerHandler(name, (data, callback) => {
    cb(data)
  })
}
