window.__bridge = null
window.__setupWebViewJavascriptBridge = function (callback) {
  if (window.WebViewJavascriptBridge) {
    return callback(window.WebViewJavascriptBridge)
  }
  if (window.WVJBCallbacks) {
    return window.WVJBCallbacks.push(callback)
  }
  window.WVJBCallbacks = [callback]
  var WVJBIframe = document.createElement('iframe')
  WVJBIframe.style.display = 'none'
  WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__'
  document.documentElement.appendChild(WVJBIframe)
  setTimeout(function () {
    document.documentElement.removeChild(WVJBIframe)
  }, 0)
}
window.__setupWebViewJavascriptBridge(function (b) {
  window.__bridge = b
})
window.___WebToApp = function (name, params, cb) {
  if (window.__bridge) {
    window.__bridge.callHandler(name, params, function (responseData) {
      cb(responseData)
    })
  } else {
    window.__setupWebViewJavascriptBridge(function (b) {
      window.__bridge = b
      window.__bridge.callHandler(name, params, function (responseData) {
        cb(responseData)
      })
    })
  }
}
window.__AppToWeb = function (name, cb) {
  if (window.__bridge) {
    window.__bridge.registerHandler(name, (data, callback) => {
      cb(data)
    })
  } else {
    window.__setupWebViewJavascriptBridge(function (b) {
      window.__bridge = b
      window.__bridge.registerHandler(name, (data, callback) => {
        cb(data)
      })
    })
  }
}
